import tkinter as tk
from tkinter import ttk
import numpy as np
import skfuzzy as fuzz
from skfuzzy import control as ctrl
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import seaborn as sns

class SmartLightingSystem:
    def __init__(self):
        # Fuzzy değişkenlerini tanımlama
        # Girdiler
        self.ambient_light = ctrl.Antecedent(np.arange(0, 1001, 1), 'ambient_light')
        self.time_of_day = ctrl.Antecedent(np.arange(0, 24, 1), 'time_of_day')
        self.room_occupancy = ctrl.Antecedent(np.arange(0, 2, 1), 'room_occupancy')
        self.user_activity = ctrl.Antecedent(np.arange(0, 4, 1), 'user_activity')
        self.weather = ctrl.Antecedent(np.arange(0, 3, 1), 'weather')

        # Çıktılar
        self.light_intensity = ctrl.Consequent(np.arange(0, 101, 1), 'light_intensity')
        self.light_color = ctrl.Consequent(np.arange(0, 3, 1), 'light_color')

        # Üyelik fonksiyonlarını tanımlama
        # Ortam ışığı
        self.ambient_light['karanlik'] = fuzz.trapmf(self.ambient_light.universe, [0, 0, 200, 400])
        self.ambient_light['normal'] = fuzz.trapmf(self.ambient_light.universe, [200, 400, 600, 800])
        self.ambient_light['aydinlik'] = fuzz.trapmf(self.ambient_light.universe, [600, 800, 1000, 1000])

        # Günün saati
        self.time_of_day['sabah'] = fuzz.trapmf(self.time_of_day.universe, [0, 0, 6, 9])
        self.time_of_day['ogle'] = fuzz.trapmf(self.time_of_day.universe, [8, 11, 13, 16])
        self.time_of_day['aksam'] = fuzz.trapmf(self.time_of_day.universe, [15, 18, 20, 22])
        self.time_of_day['gece'] = fuzz.trapmf(self.time_of_day.universe, [21, 23, 24, 24])

        # Oda doluluk durumu
        self.room_occupancy['bos'] = fuzz.trimf(self.room_occupancy.universe, [0, 0, 0.5])
        self.room_occupancy['dolu'] = fuzz.trimf(self.room_occupancy.universe, [0.5, 1, 1])

        # Kullanıcı aktivitesi
        self.user_activity['uyuma'] = fuzz.trimf(self.user_activity.universe, [0, 0, 1])
        self.user_activity['okuma'] = fuzz.trimf(self.user_activity.universe, [0, 1, 2])
        self.user_activity['dinlenme'] = fuzz.trimf(self.user_activity.universe, [1, 2, 3])
        self.user_activity['hareket'] = fuzz.trimf(self.user_activity.universe, [2, 3, 3])

        # Hava durumu
        self.weather['gunesli'] = fuzz.trimf(self.weather.universe, [0, 0, 1])
        self.weather['kapali'] = fuzz.trimf(self.weather.universe, [0, 1, 2])
        self.weather['yagmurlu'] = fuzz.trimf(self.weather.universe, [1, 2, 2])

        # Işık şiddeti
        self.light_intensity['dusuk'] = fuzz.trimf(self.light_intensity.universe, [0, 20, 40])
        self.light_intensity['orta'] = fuzz.trimf(self.light_intensity.universe, [30, 50, 70])
        self.light_intensity['yuksek'] = fuzz.trimf(self.light_intensity.universe, [60, 80, 100])

        # Işık rengi
        self.light_color['sicak'] = fuzz.trimf(self.light_color.universe, [0, 0, 1])
        self.light_color['notr'] = fuzz.trimf(self.light_color.universe, [0, 1, 2])
        self.light_color['soguk'] = fuzz.trimf(self.light_color.universe, [1, 2, 2])

        # Kuralları tanımlama
        # Temel kurallar
        rule1 = ctrl.Rule(
            self.ambient_light['karanlik'] & self.time_of_day['gece'] & 
            self.room_occupancy['dolu'] & self.user_activity['uyuma'], 
            (self.light_intensity['dusuk'], self.light_color['sicak'])
        )
        
        rule2 = ctrl.Rule(
            self.ambient_light['normal'] & self.time_of_day['ogle'] & 
            self.room_occupancy['dolu'] & self.user_activity['okuma'], 
            (self.light_intensity['orta'], self.light_color['notr'])
        )
        
        rule3 = ctrl.Rule(
            self.ambient_light['aydinlik'] & self.time_of_day['sabah'] & 
            self.room_occupancy['dolu'] & self.user_activity['hareket'], 
            (self.light_intensity['yuksek'], self.light_color['soguk'])
        )

        # Hava durumu kuralları
        rule4 = ctrl.Rule(
            self.weather['yagmurlu'] & self.ambient_light['karanlik'],
            (self.light_intensity['orta'], self.light_color['sicak'])
        )

        rule5 = ctrl.Rule(
            self.weather['gunesli'] & self.ambient_light['aydinlik'],
            (self.light_intensity['dusuk'], self.light_color['notr'])
        )

        # Varsayılan kurallar
        rule6 = ctrl.Rule(
            self.room_occupancy['bos'],
            (self.light_intensity['dusuk'], self.light_color['notr'])
        )

        rule7 = ctrl.Rule(
            self.user_activity['dinlenme'],
            (self.light_intensity['orta'], self.light_color['sicak'])
        )

        # Ek kurallar
        rule8 = ctrl.Rule(
            self.time_of_day['aksam'] & self.room_occupancy['dolu'],
            (self.light_intensity['orta'], self.light_color['sicak'])
        )

        rule9 = ctrl.Rule(
            self.weather['kapali'] & self.ambient_light['normal'],
            (self.light_intensity['orta'], self.light_color['notr'])
        )

        # Varsayılan çıktı kuralı
        rule10 = ctrl.Rule(
            self.ambient_light['normal'] | self.time_of_day['ogle'],
            (self.light_intensity['orta'], self.light_color['notr'])
        )

        # Kontrol sistemi oluşturma
        self.lighting_ctrl = ctrl.ControlSystem([
            rule1, rule2, rule3, rule4, rule5, rule6, rule7, rule8, rule9, rule10
        ])
        self.lighting_sim = ctrl.ControlSystemSimulation(self.lighting_ctrl)

    def calculate_lighting(self, ambient_light, time_of_day, room_occupancy, user_activity, weather):
        try:
            # Girdi değerlerini kontrol et ve sınırla
            ambient_light = max(0, min(1000, ambient_light))
            time_of_day = max(0, min(24, time_of_day))
            room_occupancy = max(0, min(1, room_occupancy))
            user_activity = max(0, min(3, user_activity))
            weather = max(0, min(2, weather))
            
            self.lighting_sim.input['ambient_light'] = ambient_light
            self.lighting_sim.input['time_of_day'] = time_of_day
            self.lighting_sim.input['room_occupancy'] = room_occupancy
            self.lighting_sim.input['user_activity'] = user_activity
            self.lighting_sim.input['weather'] = weather
            
            self.lighting_sim.compute()
            
            # Çıktıları kontrol et
            intensity = max(0, min(100, self.lighting_sim.output['light_intensity']))
            color = max(0, min(2, self.lighting_sim.output['light_color']))
            
            return {
                'intensity': intensity,
                'color': color
            }
        except Exception as e:
            print(f"Hesaplama hatası: {e}")
            return {'intensity': 50, 'color': 1}  # Varsayılan değerler

    def plot_membership_functions(self):
        fig = Figure(figsize=(12, 8))
        
        # Ortam ışığı üyelik fonksiyonları
        ax1 = fig.add_subplot(321)
        for term in self.ambient_light.terms:
            ax1.plot(self.ambient_light.universe, self.ambient_light[term].mf, label=term)
        ax1.set_title('Ortam Işığı Üyelik Fonksiyonları')
        ax1.legend()
        
        # Günün saati üyelik fonksiyonları
        ax2 = fig.add_subplot(322)
        for term in self.time_of_day.terms:
            ax2.plot(self.time_of_day.universe, self.time_of_day[term].mf, label=term)
        ax2.set_title('Günün Saati Üyelik Fonksiyonları')
        ax2.legend()
        
        # Işık şiddeti üyelik fonksiyonları
        ax3 = fig.add_subplot(323)
        for term in self.light_intensity.terms:
            ax3.plot(self.light_intensity.universe, self.light_intensity[term].mf, label=term)
        ax3.set_title('Işık Şiddeti Üyelik Fonksiyonları')
        ax3.legend()
        
        # Işık rengi üyelik fonksiyonları
        ax4 = fig.add_subplot(324)
        for term in self.light_color.terms:
            ax4.plot(self.light_color.universe, self.light_color[term].mf, label=term)
        ax4.set_title('Işık Rengi Üyelik Fonksiyonları')
        ax4.legend()
        
        fig.tight_layout()
        return fig

class SmartLightingGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Akıllı Aydınlatma Kontrol Sistemi")
        self.root.geometry("1200x800")
        self.root.configure(bg='#f0f0f0')
        
        self.system = SmartLightingSystem()
        
        # Stil tanımlamaları
        style = ttk.Style()
        style.configure('TFrame', background='#f0f0f0')
        style.configure('TLabel', background='#f0f0f0', font=('Helvetica', 10))
        style.configure('TButton', font=('Helvetica', 10, 'bold'))
        style.configure('Header.TLabel', font=('Helvetica', 12, 'bold'))
        
        # Ana frame
        main_frame = ttk.Frame(root, padding="20", style='TFrame')
        main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Başlık
        header = ttk.Label(main_frame, text="Akıllı Aydınlatma Kontrol Sistemi", 
                          style='Header.TLabel')
        header.grid(row=0, column=0, columnspan=2, pady=(0, 20))
        
        # Sol panel - Girdiler
        input_frame = ttk.Frame(main_frame, padding="10", style='TFrame')
        input_frame.grid(row=1, column=0, sticky=(tk.W, tk.E, tk.N, tk.S), padx=(0, 10))
        
        # Girdi değişkenleri
        ttk.Label(input_frame, text="Ortam Işığı (lux):", style='TLabel').grid(row=0, column=0, sticky=tk.W, pady=5)
        self.ambient_light = ttk.Scale(input_frame, from_=0, to=1000, orient=tk.HORIZONTAL, length=300)
        self.ambient_light.grid(row=0, column=1, sticky=(tk.W, tk.E), pady=5)
        
        ttk.Label(input_frame, text="Günün Saati:", style='TLabel').grid(row=1, column=0, sticky=tk.W, pady=5)
        self.time_of_day = ttk.Combobox(input_frame, values=["Sabah", "Öğle", "Akşam", "Gece"], width=30)
        self.time_of_day.grid(row=1, column=1, sticky=(tk.W, tk.E), pady=5)
        
        ttk.Label(input_frame, text="Oda Doluluk Durumu:", style='TLabel').grid(row=2, column=0, sticky=tk.W, pady=5)
        self.room_occupancy = ttk.Combobox(input_frame, values=["Boş", "Dolu"], width=30)
        self.room_occupancy.grid(row=2, column=1, sticky=(tk.W, tk.E), pady=5)
        
        ttk.Label(input_frame, text="Kullanıcı Aktivitesi:", style='TLabel').grid(row=3, column=0, sticky=tk.W, pady=5)
        self.user_activity = ttk.Combobox(input_frame, values=["Uyuma", "Okuma", "Dinlenme", "Hareket"], width=30)
        self.user_activity.grid(row=3, column=1, sticky=(tk.W, tk.E), pady=5)
        
        ttk.Label(input_frame, text="Hava Durumu:", style='TLabel').grid(row=4, column=0, sticky=tk.W, pady=5)
        self.weather = ttk.Combobox(input_frame, values=["Güneşli", "Kapalı", "Yağmurlu"], width=30)
        self.weather.grid(row=4, column=1, sticky=(tk.W, tk.E), pady=5)
        
        # Hesaplama butonu
        ttk.Button(input_frame, text="Hesapla", command=self.calculate, style='TButton').grid(
            row=5, column=0, columnspan=2, pady=20)
        
        # Sonuç etiketleri
        self.result_intensity = ttk.Label(input_frame, text="Işık Şiddeti: ", style='TLabel')
        self.result_intensity.grid(row=6, column=0, columnspan=2, sticky=tk.W, pady=5)
        
        self.result_color = ttk.Label(input_frame, text="Işık Rengi: ", style='TLabel')
        self.result_color.grid(row=7, column=0, columnspan=2, sticky=tk.W, pady=5)
        
        # Sağ panel - Grafikler
        self.graph_frame = ttk.Frame(main_frame, padding="10", style='TFrame')
        self.graph_frame.grid(row=1, column=1, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Üyelik fonksiyonları grafiği
        fig = self.system.plot_membership_functions()
        self.canvas = FigureCanvasTkAgg(fig, master=self.graph_frame)
        self.canvas.draw()
        self.canvas.get_tk_widget().grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))
        
        # Varsayılan değerleri ayarla
        self.time_of_day.set("Sabah")
        self.room_occupancy.set("Dolu")
        self.user_activity.set("Okuma")
        self.weather.set("Güneşli")

    def calculate(self):
        try:
            # Girdi değerlerini al
            ambient_light = self.ambient_light.get()
            
            time_map = {"Sabah": 6, "Öğle": 12, "Akşam": 18, "Gece": 23}
            time_of_day = time_map[self.time_of_day.get()]
            
            room_map = {"Boş": 0, "Dolu": 1}
            room_occupancy = room_map[self.room_occupancy.get()]
            
            activity_map = {"Uyuma": 0, "Okuma": 1, "Dinlenme": 2, "Hareket": 3}
            user_activity = activity_map[self.user_activity.get()]
            
            weather_map = {"Güneşli": 0, "Kapalı": 1, "Yağmurlu": 2}
            weather = weather_map[self.weather.get()]
            
            # Hesaplama yap
            result = self.system.calculate_lighting(
                ambient_light, time_of_day, room_occupancy, user_activity, weather
            )
            
            # Sonuçları göster
            intensity_map = {
                (0, 40): "Düşük",
                (30, 90): "Orta",
                (80, 100): "Yüksek"
            }
            
            color_map = {
                (0, 1): "Sıcak",
                (0, 2): "Nötr",
                (1, 2): "Soğuk"
            }
            
            intensity = next(v for (min_val, max_val), v in intensity_map.items() 
                            if min_val <= result['intensity'] <= max_val)
            
            color = next(v for (min_val, max_val), v in color_map.items() 
                        if min_val <= result['color'] <= max_val)
            
            self.result_intensity.config(text=f"Işık Şiddeti: {intensity} ({result['intensity']:.1f})")
            self.result_color.config(text=f"Işık Rengi: {color}")
            
        except Exception as e:
            print(f"Hata: {e}")
            self.result_intensity.config(text="Hesaplama hatası!")
            self.result_color.config(text="Hesaplama hatası!")

if __name__ == "__main__":
    root = tk.Tk()
    app = SmartLightingGUI(root)
    root.mainloop() 