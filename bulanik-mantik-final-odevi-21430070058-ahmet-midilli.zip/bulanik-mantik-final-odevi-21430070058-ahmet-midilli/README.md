# Akıllı Aydınlatma Kontrol Sistemi

Bu proje, bulanık mantık kullanarak akıllı aydınlatma kontrolü yapan bir sistemdir. Sistem, çeşitli girdilere göre en uygun aydınlatma şiddeti ve rengini belirler.

## Özellikler

- 5 girdi değişkeni:
  - Ortam ışığı seviyesi (lux)
  - Günün saati (sabah/öğle/akşam/gece)
  - Oda doluluk durumu (boş/dolu)
  - Kullanıcı aktivitesi (uyuma/okuma/dinlenme/hareket)
  - Dış ortam güneş durumu (güneşli/kapalı/yağmurlu)

- 2 çıktı değişkeni:
  - Aydınlatma şiddeti (düşük/orta/yüksek)
  - Işık rengi (sıcak/nötr/soğuk)

## Gereksinimler

- Python 3.x
- numpy
- scikit-fuzzy
- tkinter (Python ile birlikte gelir)

## Kurulum

1. Projeyi klonlayın:
```bash
git clone https://github.com/Ahmet-Midilli/bulanik-mantik-finali.git
cd bulanik-mantik-final-odevi-21430070058-ahmet-midilli
```

2. Gerekli paketleri yükleyin:
```bash
pip install -r requirements.txt
```

## Kullanım

Programı çalıştırmak için:
```bash
python smart_lighting_system.py
```

### Arayüz Kullanımı

1. Ortam ışığı seviyesini ayarlamak için kaydırıcıyı kullanın (0-1000 lux arası)
2. Günün saatini seçin (Sabah/Öğle/Akşam/Gece)
3. Oda doluluk durumunu seçin (Boş/Dolu)
4. Kullanıcı aktivitesini seçin (Uyuma/Okuma/Dinlenme/Hareket)
5. Hava durumunu seçin (Güneşli/Kapalı/Yağmurlu)
6. "Hesapla" butonuna tıklayın
7. Sonuçlar ekranın alt kısmında görüntülenecektir

## Bulanık Mantık Kuralları

Sistem, aşağıdaki temel kurallara göre çalışır:

1. Gece, karanlık ve uyuma durumunda: Düşük şiddetli, sıcak renkli aydınlatma
2. Öğle, normal ışık ve okuma durumunda: Orta şiddetli, nötr renkli aydınlatma
3. Sabah, aydınlık ve hareket durumunda: Yüksek şiddetli, soğuk renkli aydınlatma

